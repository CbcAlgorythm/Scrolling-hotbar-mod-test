# Minecraft-Smooth-Scrolling
Scroll smoothly

This fabricmc mod adds smooth scrolling to various screens in Minecraft, for example: chat, hotbar, creative inventory and server/world/resourcepack... list.

https://modrinth.com/mod/smooth-scroll

![icon](https://github.com/SmajloSlovakian/Minecraft-Smooth-Scrolling/assets/16209307/d4bf967b-9ee0-4e94-af9c-7dc0c5a984a2)
