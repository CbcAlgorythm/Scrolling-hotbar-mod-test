# How to Build This Mod

## Quick Start

**On Mac/Linux:**
```bash
cd Minecraft-Smooth-Scrolling
./build.sh
```

**On Windows:**
```batch
cd Minecraft-Smooth-Scrolling
build.bat
```

That's it! The JAR will be in `build/libs/`

## Manual Method

If the scripts don't work:

**Mac/Linux:**
```bash
cd Minecraft-Smooth-Scrolling
chmod +x gradlew
./gradlew build
```

**Windows:**
```batch
cd Minecraft-Smooth-Scrolling
gradlew.bat build
```

## Troubleshooting

**"No such file or directory: ./gradlew"**
- Make sure you're inside the `Minecraft-Smooth-Scrolling` folder
- After extracting the ZIP, you need to `cd` into it first

**"Permission denied"**
```bash
chmod +x gradlew
./gradlew build
```

**"Unsupported class file major version"**
- You need Java 17 or newer
- Download from https://adoptium.net/

**Build takes forever**
- First build downloads dependencies (5-10 minutes)
- This is normal!

**Still stuck?**
1. Make sure you have Java 17+ installed: `java -version`
2. Make sure you have internet connection
3. Try deleting `.gradle` folder and building again
4. Try `./gradlew clean build` instead

## Your Built Mod

After building, you'll find:
```
build/libs/smoothscroll-2.6.1+1.20.1.jar
```

Copy this to your Minecraft mods folder!

## What's Fixed in This Version

✅ Works with Minecraft 1.20.1
✅ Fixed crash with getSelectedSlot()
✅ Smooth hotbar scrolling
✅ Smooth creative inventory
✅ Smooth widgets
✅ All features except chat scrolling

❌ Chat scrolling removed (API changed in 1.21.x)
