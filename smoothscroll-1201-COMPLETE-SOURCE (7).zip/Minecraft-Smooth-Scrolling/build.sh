#!/bin/bash

echo "======================================"
echo "Smooth Scroll 1.20.1 Builder"
echo "======================================"
echo ""

# Check if we're in the right directory
if [ ! -f "gradlew" ]; then
    echo "❌ Error: gradlew not found!"
    echo ""
    echo "Make sure you're in the Minecraft-Smooth-Scrolling directory:"
    echo "  cd Minecraft-Smooth-Scrolling"
    echo "  ./build.sh"
    exit 1
fi

echo "✓ Found gradlew"
echo ""

# Make sure gradlew is executable
chmod +x gradlew
echo "✓ Set execute permissions"
echo ""

# Check Java version
if command -v java &> /dev/null; then
    JAVA_VERSION=$(java -version 2>&1 | head -1 | cut -d'"' -f2 | cut -d'.' -f1)
    echo "✓ Java version: $JAVA_VERSION"
    
    if [ "$JAVA_VERSION" -lt 17 ]; then
        echo ""
        echo "⚠️  Warning: Java 17 or higher is required!"
        echo "   Your version: $JAVA_VERSION"
        echo "   Download Java 17: https://adoptium.net/"
        exit 1
    fi
else
    echo "❌ Java not found!"
    echo "   Download Java 17: https://adoptium.net/"
    exit 1
fi

echo ""
echo "Building mod..."
echo "======================================"
echo ""

# Build the mod
./gradlew build

# Check if build was successful
if [ $? -eq 0 ]; then
    echo ""
    echo "======================================"
    echo "✅ Build successful!"
    echo ""
    echo "Your mod is ready:"
    echo "  build/libs/smoothscroll-2.6.1+1.20.1.jar"
    echo ""
    echo "Copy this file to your Minecraft mods folder!"
    echo "======================================"
else
    echo ""
    echo "======================================"
    echo "❌ Build failed!"
    echo ""
    echo "Common fixes:"
    echo "1. Make sure you have internet connection"
    echo "2. Try: ./gradlew clean build"
    echo "3. Check you have Java 17+"
    echo "======================================"
    exit 1
fi
