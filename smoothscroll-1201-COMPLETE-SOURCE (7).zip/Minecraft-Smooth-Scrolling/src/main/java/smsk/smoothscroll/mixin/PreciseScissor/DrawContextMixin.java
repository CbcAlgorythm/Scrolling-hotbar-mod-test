package smsk.smoothscroll.mixin.PreciseScissor;

import org.spongepowered.asm.mixin.Mixin;
import net.minecraft.client.gui.DrawContext;

// This mixin is disabled for 1.20.1 as it's an optional feature
// If you want precise scissor support, you'll need to update the method targets

@Mixin(DrawContext.class)
public class DrawContextMixin {
    
    // Disabled - optional feature
    //@Redirect(method = "setScissor", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/util/Window;getScaleFactor()D"))
    //private double windowScale(Window w) {
    //    if (!SmoothSc.preciseScissor) return w.getScaleFactor();
    //    return 1;
    //}
}
