package smsk.smoothscroll.mixin.PreciseScissor;

import org.spongepowered.asm.mixin.Mixin;
import net.minecraft.client.gui.ScreenRect;

// This mixin is disabled for 1.20.1 as it's an optional feature
// If you want precise scissor support, you'll need to update the method targets

@Mixin(ScreenRect.class)
public class ScreenRectMixin {

    // Disabled - optional feature
    //@Redirect(method = "transform", at = @At(value = "INVOKE", target = "Lnet/minecraft/util/math/MathHelper;floor(F)I"))
    //private int windowScale(float val) {
    //    if (!SmoothSc.preciseScissor) return MathHelper.floor(val);
    //    return MathHelper.floor(val * SmoothSc.mc.getWindow().getScaleFactor());
    //}
}
